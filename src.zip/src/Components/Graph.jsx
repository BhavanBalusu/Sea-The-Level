import { React } from 'react';
import '../Styles/Graph.css';
import figure1 from '../Images/Figure_1.png';

function Graph() {
    return (
        <div className="Main">
            <h1>
                Analyze
            </h1>
            <div className="graph-container">
                <div class="textContainer">
                    <div className="imageText">
                        <h1 class="title graph">Graph Area</h1>
                        <p class="image-description">
                            Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quisquam excepturi nobis perspiciatis, temporibus nemo sed nulla id reprehenderit ut a asperiores libero eaque omnis laudantium saepe est dicta incidunt molestias sunt, fuga deleniti odit, velit accusantium? Reprehenderit nulla molestias veritatis.
                        </p>
                    </div>
                </div>

                <img src={figure1} style={{width: "600px", height:"600px"}}></img>
            </div>
        </div>
    )
}

export default Graph;